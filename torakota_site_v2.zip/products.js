// Products data for TORAkota - vertical list with description and WA link template
const WA_NUMBER = "6285730268458"; // international format, no '+' or leading 0
const WA_TEMPLATE = "Halo admin, saya ingin pesan {nama produk}?"; // user's chosen template

const products = [
  {
    nama: "Arabica Ijen Blue Mountain",
    desc: "Body halus, acidity lembut, aroma citrus floral dengan aftertaste madu.",
    thumb: "arabica-ijen.png"
  },
  {
    nama: "Arabica Kayu Aro",
    desc: "Aroma bunga, body medium, nota coklat susu dan almond panggang.",
    thumb: "arabica-kayuaro.png"
  },
  {
    nama: "Robusta Dampit Malang",
    desc: "Rasa bold, aftertaste coklat pekat, aroma smoky ringan.",
    thumb: "robusta-dampit.png"
  },
  {
    nama: "Robusta Jember Bold",
    desc: "Kekuatan penuh, crema tebal, cocok untuk espresso tradisional.",
    thumb: "robusta-jember.png"
  },
  {
    nama: "Kopi Ijo Tulungagung (Green Coffee)",
    desc: "Bijian kopi hijau khas Tulungagung, cocok untuk olahan tradisional dan eksperimen rasa.",
    thumb: "kopi-ijo.png"
  },
  {
    nama: "Teh Hitam Malang Premium",
    desc: "Aroma malt, rasa earthy stabil, cocok diminum hangat maupun dingin.",
    thumb: "teh-hitam-malang.png"
  },
  {
    nama: "Teh Melati Wangi",
    desc: "Aroma melati lembut, aftertaste manis floral, sangat populer untuk sore hari.",
    thumb: "teh-melati.png"
  },
  {
    nama: "Teh Rempah Madura",
    desc: "Blend teh dengan rempah tradisional, hangat dan aromatik, cocok untuk cuaca dingin.",
    thumb: "teh-rempah.png"
  },
  {
    nama: "Coklat Bubuk Blitar Dark Cacao",
    desc: "Dark chocolate aroma, hint karamel, kaya antioksidan, cocok untuk minuman dan kue.",
    thumb: "coklat-blitar.png"
  }
];

const container = document.getElementById('products');
function urlEncode(text){ return encodeURIComponent(text); }

products.forEach((p, idx) => {
  const card = document.createElement('a');
  card.className = 'product-card';
  // build WA link with template
  const message = WA_TEMPLATE.replace('{nama produk}', p.nama);
  const waLink = `https://wa.me/${WA_NUMBER}?text=${urlEncode(message)}`;
  card.href = waLink;
  card.target = "_blank";
  card.innerHTML = `
    <div class="product-thumb">${p.nama.split(' ')[0]}</div>
    <div class="product-body">
      <div class="prod-name">${p.nama}</div>
      <div class="prod-desc">${p.desc}</div>
      <div class="prod-meta">
        <div class="price-sample">Mulai dari: <strong>Hubungi WA</strong></div>
        <div><span class="wa-btn">Chat <span style="font-size:14px">WA</span></span></div>
      </div>
    </div>
  `;
  container.appendChild(card);
});

/* Intersection Observer for slide-up animation */
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if(entry.isIntersecting){
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, {threshold:0.15});

document.querySelectorAll('.product-card').forEach(el => observer.observe(el));

/* set WA quick fixed button to open chat (default to general message) */
const waFixed = document.getElementById('wa-fixed');
waFixed.href = `https://wa.me/${WA_NUMBER}?text=${urlEncode("Halo admin, saya ingin informasi produk TORAkota.")}`;
